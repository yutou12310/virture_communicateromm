package programming3.chatsys.data;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;

import static org.junit.jupiter.api.Assertions.*;

class SQLiteDatabaseTest {
    private final File DB_FILE = new File("test.db");
    protected User user1;
    protected User user2;
    protected ChatMessage message1;
    protected ChatMessage message2;
    protected ChatMessage message3;
    protected Database db;


    protected void initDatabase() {
        DB_FILE.delete();
        db = new SQLiteDatabase("jdbc:sqlite:" + DB_FILE.getPath());
    }

    /**
     * add some information before test
     */
    @BeforeEach
    void setUp() {
        user1 = new User("wyt","123456","wangyutao");
        user2 = new User("abc","654321","yutou");
        message1 = new ChatMessage(1,"wyt","hello");
        message2 = new ChatMessage(2,"wyt","world");
        message3 = new ChatMessage(3,"wyt","hello world");
        this.initDatabase();
    }

    @AfterEach
    void tearDown() {
        //db.close();
    }

    /**
     * register a user
     */
    @Test
    void register() {
       db.register(user1);
       db.register(user2);
//       assertTrue(db.register(user1));
//       assertTrue(db.register(user2));
    }

    /**
     * get the number of total
     */
    @Test
    void getNumberUsers() {
        db.register(user1);
        db.register(user2);
        assertEquals(2,db.getNumberUsers());

    }

    /**
     * get the user added in the database
     */
    @Test
    void getUser() {
        System.out.println(db.getUser("wyt"));
      // assertEquals(user1.toString(),db.getUser("wyt").toString());
    }

    /**
     * check the users added in the database
     */
    @Test
    void authenticate() {
        db.register(user1);
        db.register(user2);
        assertTrue(db.authenticate("wyt","123456"));
        assertFalse(db.authenticate("wyt","123321"));
        assertTrue(db.authenticate("abc","654321"));
        assertFalse(db.authenticate("abc","090909"));
        assertFalse(db.authenticate("wywerr","65432112"));
    }

    /**
     * add a message
     */
    @Test
    void addMessage() {
        db.register(user1);
        db.addMessage("wyt","hello");
        db.addMessage("wyt","world");
        db.addMessage("wyt","1111111");
        //assertEquals("ChatMessage{ID=null, user='wyt', time=2021-11-17 21:33:44.564, message='hello'}",db.addMessage("wyt","hello").toString());
    }

    /**
     * get the number of messages
     */
    @Test
    void getNumberMessages() {
        db.register(user1);
        assertEquals(3,db.getNumberMessages());
    }

    /**
     * get the recent message
     */
    @Test
    void getRecentMessages() {
        db.getRecentMessages(2);
        System.out.println(db.getRecentMessages(2));
    }

    /**
     * get the unread message
     */
    @Test
    void getUnreadMessages() {
        System.out.println(db.getUnreadMessages("wyt"));
    }

    @Test
    void close() {
    }
}