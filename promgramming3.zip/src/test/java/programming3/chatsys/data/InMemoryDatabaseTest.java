package programming3.chatsys.data;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


 class InMemoryDatabaseTest {
    protected User user1;
    protected User user2;
    protected Database db;
    protected ChatMessage message1;
    protected ChatMessage message2;

     /**
      * define some necessary message before test
      */
    @BeforeEach
    void setUp() {
        user1 = new User("wy","123456","wangyutao");
        user2 = new User("abc","654321","ni die");
        // user3 = user1;
        message1 = new ChatMessage(1,"wy","dai bi");
        message2 = new ChatMessage(2,"abc","wo shi sha bi ");
//        db.register(user1);
//        db.register(user2);
       // db.addMessage("wy","hello");
       // db.addMessage("wy","world");
//        db.getNumberUsers();
//        db.getNumberMessages();
       // db.getRecentMessages(2);
        this.initDatabase();
    }

     /**
      * set uo an initDatabase equals to InMemoryDatabase
      */
    protected void initDatabase() {
        db = new InMemoryDatabase();
    }

    @AfterEach
    void tearDown() {
        db.close();
    }

     /**
      * test if the username and password equals to the registered
      */
    @Test
    void authenticate() {
        db.register(user1);
        db.register(user2);
      assertTrue(db.authenticate("wy","123456"));
      assertFalse(db.authenticate("wy","123321"));
      assertTrue(db.authenticate("abc","654321"));
      assertFalse(db.authenticate("abc","090909"));
      assertFalse(db.authenticate("wywerr","65432112"));


    }

     /**
      * test if the users have been registered
      */
     @Test
    void register(){
         assertTrue(db.register(user1));
         assertTrue(db.register(user2));
    }


     /**
      * test the number of users and messages is correct
      */
    @Test
    void NewDatabase(){
        db.register(user1);
        db.register(user2);
        db.addMessage("wy","dai bi");
        db.addMessage("abc","wo shi sha bi");
        System.out.println(db.getNumberUsers());
        System.out.println(db.getRecentMessages(1));
        assertEquals(2,db.getNumberUsers());
        assertEquals(2,db.getNumberMessages());
    }


     /**
      * test if we can get the correct recentMessage
      */
    @Test
    void GetRecentMassage(){
        db.register(user1);
        db.addMessage("wy","world");
        System.out.println(db.getRecentMessages(1));
        assertEquals(db.getRecentMessages(1),db.getRecentMessages(1));
        assertEquals("wy",db.getUser("wy").getUserName());
        assertEquals("world",db.getRecentMessages(1).get(0).getMessage());
    }

     /**
      * test if users can add message
      */
    @Test
    void AddMessage(){
        db.register(user1);
//        db.addMessage("wy","hello");
//        db.addMessage("abc","world");
      System.out.println(db.addMessage("wy","hello"));
      System.out.println(db.addMessage("wy","world"));
//    assertEquals("hello",db.addMessage("wy","hello").getMessage());
      assertEquals("world",db.getRecentMessages(2).get(1).getMessage());
      //test the timestamp
        int compare = db.getRecentMessages(2).get(1).getTime().compareTo(db.getRecentMessages(1).get(0).getTime());
        if (compare > 0)
            System.out.println("true");
        else
            System.out.println("False");


    }
//    @Test
//    void testAddMessageInvalidUser(){
//        db.register(user1);
//        if (db.getUser("wy").getUserName() == db.getRecentMessages(1).get(0).getUser())
//           //if(db.addMessage("wy","hello").getMessage() == db.getRecentMessages)
//            System.out.println("TRUE");
//        else
//            System.out.println("not_register");
//        }


    @Test
     void  close(){
        this.db.close();
    }

     /**
      * a new method which used in the textDatabaseTest, it can help test the db_file delete
      */
    @Test
     void addmessage(){
        db.register(user1);
        db.register(user2);
        db.addMessage("wy","nie mama di");
        db.addMessage("abc","hello");
    }
}
