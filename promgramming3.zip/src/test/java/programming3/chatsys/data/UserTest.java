package programming3.chatsys.data;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static junit.framework.TestCase.assertNotSame;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

 class UserTest {

        private User user1;
        private User user2;
        private User user3;

       private final JSONObject jsonwyt = new JSONObject("{username:wyt,password:\"123456\",fullname:\"wang yutao\"}");
       private final JSONObject jsonabc = new JSONObject("{username:abc,password:\"654321\",fullname:\"ni die\"}");

     /**
      * define some information
      */
        @BeforeEach
        void setUp() {
            user1 = new User("wyt", "123456", "wang yutao");
            user2 = new User("abc", "654321", "ni die");
            user3 = user1;
        }

        @AfterEach
        void tearDown() {
        }

     /**
      * test users are unique and same
      */
        @Test
        void testEquals() {
            assertSame(user1, user3);
            assertEquals(user3, user1);
            assertNotEquals(user2, user1);
        }

     /**
      * test the format
      */
        @Test
        void testFormat() {
            assertEquals("wyt\t123456\twang yutao\t0", user1.format());
        }

     /**
      * test the parse
      */
        @Test
        void testParse() {
            user1.parse("wyt\twang yutao\t123456\t0");
            assertEquals("wyt", user1.getUserName());
            assertEquals("wang yutao", user1.getFullName());

            assertThrows(IllegalArgumentException.class, () -> {
                user1.parse("wyt\twang yutao");
            });
        }

     /**
      * test the json form
      */
     @Test
     void testToJSON() {
         assertEquals(jsonwyt.toString(), user1.toJSON().toString());
         assertEquals(jsonabc.toString(), user2.toJSON().toString());
     }
    @Test
     void TestFromJson(){
        User wyt = new User(jsonwyt);
        assertEquals(user1, wyt);
        assertThrows(JSONException.class, () -> {
            new User(new JSONObject("{}"));
        });
        assertThrows(JSONException.class, () -> {
            new User(new JSONObject("{fullname:\"wang yutao\", password:\"123456\"}"));
        });
        assertThrows(JSONException.class, () -> {
            new User(new JSONObject("{username:wyt, password:123456}"));
        });
        assertThrows(JSONException.class, () -> {
            new User(new JSONObject("{username:wyt, fullname:\"wang yutao\"}"));
        });
        assertThrows(JSONException.class, () -> {
            new User(new JSONObject("{username:wyt, fullname:\"wang yutao\", password:123456"));
        });
        assertThrows(JSONException.class, () -> {
            new User(new JSONObject("{username:wyt, fullname:{firstname:wang, lastname:yutao}, password:123456}"));
        });
    }

    }


