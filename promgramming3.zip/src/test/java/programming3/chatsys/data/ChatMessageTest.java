package programming3.chatsys.data;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChatMessageTest {
    private ChatMessage message1;
    private ChatMessage message2;

    @BeforeEach
    void setUp() {
        message1 = new ChatMessage(1, "wyt", "hello");
        message2 = new ChatMessage(2, "wyt", "world");
    }


    @AfterEach
    void tearDown() {
    }

    @Test
    void getID() {
        assertEquals(1, message1.getID());
        assertEquals(2, message2.getID());
    }

    @Test
    void getUser() {
        assertEquals("wyt", message1.getUser());
    }

    @Test
    void getMessage() {
        assertEquals("hello", message1.getMessage());
        assertEquals("world", message2.getMessage());
    }

}