package Protocol;

import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import programming3.chatsys.data.ChatMessage;
import programming3.chatsys.data.User;

import java.io.*;
import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class JSONProtocolTest {
    private final JSONObject jsonwyt = new JSONObject("{username:wyt,password:\"123456\",fullname:\"wang yutao\"}");
    private final JSONObject jsonabc = new JSONObject("{username:abc,password:\"654321\",fullname:\"ni die\"}");
    private final JSONObject jsonmessage1 = new JSONObject("{ID:1,time:\""+(new Timestamp(System.currentTimeMillis()))+"\", message:\"hello\",username:\"wyt\"}");
    private final JSONObject jsonmessage2 = new JSONObject("{ID:2,time:\""+(new Timestamp(System.currentTimeMillis()))+"\", message:\"HELLO\",username:\"abc\"}");
    private final User wyt = new User("wyt", "123456", "wang yutao");
    private final User abc = new User("abc", "654321", "ni die");
    private final ChatMessage message1 = new ChatMessage(1,"wyt","hello");
    private final ChatMessage message2 = new ChatMessage(2,"abc","HELLO");


    /**
     * @throws IOException
     * read the users in the string form
     */
    @Test
    void readUser() throws IOException{
        JSONProtocol protocol = new JSONProtocol(new BufferedReader(new StringReader(jsonwyt.toString())));
        assertEquals(wyt, protocol.readUser());

        protocol = new JSONProtocol(new BufferedReader(new StringReader(jsonabc.toString())));
        assertEquals(abc, protocol.readUser());
    }


    /**
     * @throws IOException
     * write the users in the form of json
     */
    @Test
    void writeUser() throws IOException {
        StringWriter string = new StringWriter();
        JSONProtocol protocol = new JSONProtocol(new BufferedWriter(string));
        protocol.writeUser(wyt);
        assertEquals(jsonwyt.toString(), string.toString());

        string = new StringWriter();
        protocol = new JSONProtocol(new BufferedWriter(string));
        protocol.writeUser(abc);
        assertEquals(jsonabc.toString(), string.toString());
    }

    /**
     * @throws IOException
     * read the messages from string form
     */
    @Test
    void readMessage() throws IOException {
        //System.out.println(message1);
        LinkedList<ChatMessage> messages = new LinkedList<>();
        messages.add(message1);
        JSONProtocol protocol = new JSONProtocol(new BufferedReader(new StringReader(messages.toString())));
     //   System.out.println(jsonmessage1.toString());
      //  assertEquals(message1.toString(),protocol.readMessage().toString());
        System.out.println(protocol.readMessage().toString());

    }

    /**
     * @throws IOException
     * write the message in the form of json
     */
    @Test
    void writeMessage() throws IOException {
        LinkedList<ChatMessage> messages = new LinkedList<>();
        messages.add(message1);
        messages.add(message2);
        StringWriter string = new StringWriter();
        JSONProtocol protocol = new JSONProtocol(new BufferedWriter(string));
        protocol.writeMessage(messages);
        assertEquals(jsonmessage1.toString() + jsonmessage2.toString(), string.toString());
       //  System.out.println(string);
       // assertEquals(jsonmessage2.toString(), string.toString());
    }
}