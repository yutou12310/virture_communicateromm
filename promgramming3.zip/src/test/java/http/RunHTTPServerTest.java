package http;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RunHTTPServerTest {

    @Test
    void main() {
        // sorry, i really do not know how i can test the HttpServer, because i can always run my server successfully
    }
}