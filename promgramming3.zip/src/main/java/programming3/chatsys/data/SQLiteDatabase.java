package programming3.chatsys.data;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class SQLiteDatabase implements Database {
    private Connection connection;

    /**
     * @param url the connection url
     *this will create 2 tables, one is userTable, and the other is messageTable
     */
    public SQLiteDatabase(String url) {
        try {
            this.connection = DriverManager.getConnection(url);
            this.createUsersTable();
            this.createMessagesTable();
        } catch(SQLException e) {
            throw new DatabaseAccessException(e);
        }
    }

    /**create a userTable
     * @throws SQLException
     */
    private void createUsersTable() throws SQLException {
        String query = "CREATE TABLE IF NOT EXISTS user (\n" +
                "id integer PRIMARY KEY,\n" +
                "username text UNIQUE NOT NULL,\n" +
                "fullname text NOT NULL,\n" +
                "password text NOT NULL,\n" +
                "last_read_id integer DEFAULT 0\n" +
                ");";
        Statement statement = this.connection.createStatement();
        statement.execute(query);
    }

    /**create a messageTable
     * @throws SQLException
     */
    private void createMessagesTable() throws SQLException {
        String query = "CREATE TABLE IF NOT EXISTS chatMessage (\n" +
                "id integer PRIMARY KEY,\n" +
                "user text  NOT NULL,\n" +
                "time text NOT NULL,\n" +
                "message text NOT NULL\n" +
                ");";
        Statement statement = this.connection.createStatement();
        statement.execute(query);
    }

    /**register a user to the userTable
     * @param user the user to add.
     * @return if the user is successfully registered in the database, it will return true
     */
    @Override
    public boolean register(User user) {
        String query = "INSERT INTO user(username, fullname, password) VALUES(?, ?, ?)";
        try {
            PreparedStatement statement = this.connection.prepareStatement(query);
            statement.setString(1, user.getUserName());
            statement.setString(2, user.getFullName());
            statement.setString(3, user.getPassword());
            return statement.executeUpdate() == 1;
        } catch(SQLException e) {
            if (e.getErrorCode() == 19) {
                return false;
            } else {
                throw new DatabaseAccessException(e);
            }
        }
    }

    /**get the number of users
     * @return the num of users
     */
    @Override
    public int getNumberUsers() {
        String query = "SELECT COUNT(*) FROM user";
        try {
            Statement statement = this.connection.createStatement();
            statement.execute(query);
            return statement.getResultSet().getInt(1);
        } catch(SQLException e) {
            throw new DatabaseAccessException(e);
        }
    }

    /**get the information of user which has been registered
     * @param userName The user's username.
     * @return the registered users' information, such as username,fullname, password and last read id
     */
    @Override
    public User getUser(String userName) {
        String query = "SELECT * FROM user WHERE username = ?";
        try {
            PreparedStatement statement = this.connection.prepareStatement(query);
            statement.setString(1, userName);
            statement.execute();
            ResultSet result = statement.getResultSet();
            if (result.next()) {
                return new User(
                        result.getString("username"),
                        result.getString("fullname"),
                        result.getString("password"),
                        result.getInt("last_read_id")
                );
            } else {
                throw new IllegalArgumentException(userName + " is not a registered user");
            }
        } catch(SQLException e) {
            throw new DatabaseAccessException(e);
        }
    }

    /**check the correct of the users' username and password
     * @param userName the name of the user.
     * @param password the password of the user.
     * @return if username and password are equal to the information registered in the Database, it will return true.
     */
    @Override
    public boolean authenticate(String userName, String password) {
        String query = "SELECT COUNT(*) FROM user WHERE username = ? AND password = ?";
        try {
            PreparedStatement statement = this.connection.prepareStatement(query);
            statement.setString(1, userName);
            statement.setString(2, password);
            statement.execute();
            ResultSet result = statement.getResultSet();
            return result.getInt(1) == 1;
        } catch(SQLException e) {
            throw new DatabaseAccessException(e);
        }
    }

    /** add a new message to the messageTable
     * @param userName user who sends the message.
     * @param message  the message to add.
     * @return new chatmessage
     */
    @Override
    public ChatMessage addMessage(String userName, String message) {
       String query = "INSERT INTO chatMessage(user, time, message) VALUES(?, ?, ?) ";
        ChatMessage chatMessage = new ChatMessage(userName, message);
        try{
       PreparedStatement statement = this.connection.prepareStatement(query);
       statement.setString(1, userName);
       statement.setLong(2,chatMessage.getTime2());
       statement.setString(3, message);
       statement.execute();

       return new ChatMessage(userName,chatMessage.getTime2(),message);

       }catch (SQLException e) {
           throw new DatabaseAccessException(e);
       }
    }

    /**
     * @return get the total message added in the MessageTable
     */
    @Override
    public int getNumberMessages() {
        String query = "SELECT COUNT(*) FROM chatmessage";
        try {
            Statement statement = this.connection.createStatement();
            statement.execute(query);
            return statement.getResultSet().getInt(1);
        }catch (SQLException e){
            throw new DatabaseAccessException(e);
        }

    }

    /**
     * @param n the number of chat messages to read.
     * @return it will return the latest message you add in the messageTable
     */
    @Override
    public List<ChatMessage> getRecentMessages(int n) {
//        String query = "SELECT * FROM (SELECT chatMessage.id, username, time, message FROM chatMessage, user WHERE user.id = user ORDER BY chatMessage.id DESC LIMIT ?) ORDER BY id ASC";
        String query = "SELECT * FROM (SELECT id ID, user userName, time time2, message FROM chatMessage ORDER BY id DESC limit ?) ORDER BY id";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = this.connection.prepareStatement(query);
            ps.setInt(1,n);
            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            List<ChatMessage> list = new LinkedList<>();
            while (rs.next()){
                ChatMessage chatMessage = new ChatMessage();
                chatMessage.setID(rs.getInt("id"));
                chatMessage.setUser(rs.getString("userName"));
                chatMessage.setTime2(rs.getLong("time2"));
                chatMessage.setMessage(rs.getString("message"));
                list.add(chatMessage);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if(ps != null)
                    ps.close();
                if(rs != null)
                    rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }


    /**
     * @param userName user.
     * @return it will return the message you have read
     * if you get the latest unreadmessage, it will update last read id
     */
    @Override
    public List<ChatMessage> getUnreadMessages(String userName) {
        String query1 = "SELECT chatMessage.id, chatMessage.user userName, time time2, message FROM chatMessage, user u WHERE u.username = ? AND u.username = chatMessage.user AND u.last_read_id < chatMessage.id";
        String query2 = "UPDATE user SET last_read_id = ? WHERE username = ?";
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        ResultSet rs = null;
        try {
            ps = this.connection.prepareStatement(query1);
            ps.setString(1,userName);
            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            List<ChatMessage> list = new LinkedList<>();
            while (rs.next()){
                ChatMessage chatMessage = new ChatMessage();
                chatMessage.setID(rs.getInt("id"));
                chatMessage.setUser(rs.getString("userName"));
                chatMessage.setTime2(rs.getLong("time2"));
                chatMessage.setMessage(rs.getString("message"));
                list.add(chatMessage);
            }
            System.out.println(list);
            ps1 = this.connection.prepareStatement(query2);
    //      ps1.setInt(1,list.get(list.size()-1).getID());
            ps1.setInt(1,this.getNumberMessages());
            ps1.setString(2,userName);
            ps1.execute();
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if(ps != null)
                    ps.close();
                if(rs != null)
                    rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public void close() { }
}
