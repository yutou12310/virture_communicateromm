package programming3.chatsys.data;

public class main {
    public static void main(String[] args){
        User user1 = new User("wyt", "123456", "wangyutao");
        User user2= new User("abc", "654321", "ni die");
        ChatMessage chatMessage1 = new ChatMessage(1,"wyt","hello");
        ChatMessage chatMessage2 = new ChatMessage(2,"abc","wo shi sha bi ");
        System.out.println(user1);
        System.out.println(user2);


        Database db = new InMemoryDatabase();
        db.register(user2);
        db.addMessage("abc","hello");
        db.addMessage("abc","world");
        db.addMessage("abc","hello, world");
        System.out.println(db);
        System.out.println(db.register(user1));
        System.out.println(db.register(user2));
        System.out.println(db.getNumberUsers());
//        System.out.println(db.addMessage("wyt","dai bi"));
//        System.out.println(db.addMessage("abc","wo shi sha bi"));
//        db.addMessage("wyt","wo shi sha bi");
        System.out.println(db.getRecentMessages(2));
        System.out.println(db.getUnreadMessages("abc"));
        //System.out.println(db.getUnreadMessages("abc"));



    }

}
