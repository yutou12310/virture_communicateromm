package programming3.chatsys.data;

import java.util.*;

public class InMemoryDatabase implements Database {
    protected List<User> users;
    protected List<ChatMessage> chatMessages;
    private int lastId = 0;
    //failed code
    //private List<ChatMessage> unMessages ;
    //private List<ChatMessage> midMessages ;
    // ChatMessage chatMessage;


    /**
     * create a new database called InMemoryDatabase
     */
    public InMemoryDatabase() {
        System.out.println("start test!");
        users = new LinkedList<>();
        chatMessages = new LinkedList<>();
        //  unMessages = new LinkedList<ChatMessage>();
        //  midMessages = new LinkedList<ChatMessage>();

    }

      @Override
      public String toString() {
          return "InMemoryDatabase{" +
            "users=" + users +
            ", chatMessages=" + chatMessages +
            '}';
}

    /**
     * @param user the user to add.
     * @return if successfully register a user, it will return true, else it will return false
     */
    @Override
    public boolean register(User user) {
        if (this.contains(user)) {
            return false;
        } else {
            this.users.add(user);
            return true;
        }

    }

    /**
     * Checks whether a User with the same userName is already present in the Database.
     * @param user the User to check for inclusion.
     * @return true if there is already a User with the same userName in the Database.
     */
    private boolean contains(User user) {
        try {
            return this.getUser(user.getUserName()) != null;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /**get the number of the users
     * @return the size of List
     * @throws DatabaseAccessException can not access database
     */
    @Override
    public int getNumberUsers() throws DatabaseAccessException {
        return users.size();
    }

    /**get the username of the users who are registered
     * @param userName The user's username.
     * @return user
     * @throws DatabaseAccessException can not get the database
     * @throws IllegalArgumentException form is incorrect
     */
    @Override
    public User getUser(String userName) throws DatabaseAccessException, IllegalArgumentException {
        for (User u : this.users) {
            if (u.getUserName().equals(userName)) {
                return u;
            }
        }
        throw new IllegalArgumentException(userName + " is not a registered user");
    }

    /**check the correct of the users' username and password
     * @param userName the name of the user.
     * @param password the password of the user.
     * @return if the result is correct, it will return true, or it will return false
     * @throws DatabaseAccessException can not access the database
     */
    @Override
    public boolean authenticate(String userName, String password)
            throws DatabaseAccessException {
        for (User u : this.users) {
            if (u.getUserName().equals(userName) && u.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }


    /** add a message in list of chatMessage
     * @param userName user who sends the message.
     * @param message  the message to add.
     * @return the content of chatMessage,include username and message
     */
    @Override
    public ChatMessage addMessage(String userName, String message)  {
        for (User a : this.users) {
            if (a.getUserName().equals(userName)) {
                this.lastId++;
                System.out.println("message:"+ message);
                ChatMessage chatMessage = new ChatMessage(this.lastId, userName, message);
                this.chatMessages.add(chatMessage);
                chatMessage.setID(this.lastId);
                System.out.println(this.getRecentMessages(2));
                return chatMessage;
            }
            }throw new IllegalArgumentException("User " + userName + " is not registered.");
    }
    // i used to try to use two LinkList, but i failed to finished it.
//      for (User u: this.users){
//         if (users == null){
//            throw new IllegalArgumentException(userName+ " is not exist");
//         }
//         if (u.getUserName().equals(userName)){
//            this.lastId++;
//           ChatMessage chatMessage = new ChatMessage(this.lastId,userName,message);
//            this.chatMessages.add(chatMessage);
//          //this.unMessages.add(chatMessage);
//            return chatMessage;
//         }
//      }
//      return chatMessage;

    /**get the number of total chatMessages
     * @return the size of list of chatMessage
     * @throws DatabaseAccessException can not access the database
     * @throws IllegalArgumentException form is incorrect
     */
   @Override
   public int getNumberMessages() throws DatabaseAccessException,IllegalArgumentException{
      return chatMessages.size();
   }

    /**get the latest message, and you can choose how many messages you want
     * @param n the number of chat messages to read.
     * @return the messages added in the list
     */
   @Override
   public List<ChatMessage> getRecentMessages(int n) {
      if (n>0 && n<this.chatMessages.size()){
      return this.chatMessages.subList(chatMessages.size()-n, chatMessages.size());}
    else
       return new LinkedList<>(chatMessages);
   }

    /**get the message of the user, you can choose the username
     * @param userName user.
     * @return the messages the user post
     */
  @Override
   public List<ChatMessage> getUnreadMessages(String userName) {
      User user = this.getUser(userName);
      final int lastReadId = user.getLastReadId();
      if (lastReadId == this.lastId) {
          return new LinkedList<>();
      } else {
          int firstUnread = 0;
          for (ChatMessage m : this.chatMessages) {
              firstUnread = m.getID();
              if (firstUnread > lastReadId) {
                  break;
              }
          }
          this.getUser(userName).setLastReadId(this.lastId);
          return this.chatMessages.subList(firstUnread - 1, this.chatMessages.size());
      }
        //List<ChatMessage> midMessages = new LinkedList<ChatMessage>();
        //midMessages.addAll(unMessages);
        //unMessages.removeAll(unMessages);
        //return midMessages;
        //return null;
  }

    public List<ChatMessage> getChatMessages() {
        return chatMessages;
    }

    @Override
   public void close() {
   }


}
