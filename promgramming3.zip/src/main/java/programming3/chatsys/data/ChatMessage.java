package programming3.chatsys.data;

import org.json.JSONObject;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Objects;
// import java.text.SimpleDateFormat;

public class ChatMessage {

    private  Integer ID = 0;
    private  String userName;
    private Timestamp time = new Timestamp(System.currentTimeMillis());
    private static int x = 0;

//    {x++;}


    public long getTime2() {
        return time2;
    }

    public void setTime2(long time2) {
        this.time2 = time2;
    }

    private long time2 = System.currentTimeMillis();
    private String message;


    public ChatMessage(String userName,long u,String message) {
        this.userName = userName;
        this.time2 = u;
        this.message = message;
    }
    public ChatMessage(){         }

    public static int getX() {
        return x;
    }

    public ChatMessage(Integer ID, String userName, String message)
    {
            this.ID = ID;
            this.userName = userName;
            this.message = message;
    }



    public ChatMessage(Integer ID, String userName, long time2, String message) {
        this.ID = ID;
        this.userName = userName;
        this.time2 = time2;
        this.message = message;
    }

    public ChatMessage(String userName, String message)
    {
//        x++;
        this.ID = x;
//        this.setID(x);
//        System.out.println("x:" + x);

        this.userName = userName;
        this.message = message;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) { this.x = ID; }

    public String getUser() {
        return userName;
    }

    public void setUser(String userName) {
        this.userName = userName;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ChatMessage(String formatted) {this.parse(formatted);}

    public String format() {
        return this.userName + "\t" + this.time + "\t" + this.message + "\t" + this.ID;
    }

    @Override
    public String toString() {
        return "ChatMessage{" +
                "ID=" + x +
                ", user='" + userName + '\'' +
                ", time=" + time +
                ", message='" + message + '\'' +
                '}';
    }

    public ChatMessage(JSONObject json) {
        this.userName = json.getString("username");
        this.ID = json.getInt("ID");
        this.message = json.getString("messages");

    }

    public static java.sql.Timestamp strToSqlDate(String strDate, String dateFormat) {
        SimpleDateFormat sf = new SimpleDateFormat(dateFormat);
        java.util.Date date = null;
        try {
            date = sf.parse(strDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        java.sql.Timestamp dateSQL = new java.sql.Timestamp(date.getTime());
        return dateSQL;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ChatMessage that = (ChatMessage) o;
        return Objects.equals(userName, that.userName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userName);
    }

    public void parse(String s) {
        String[] split = s.split("\t");
        if (split.length == 4) {
            this.userName = split[0];
            this.time = strToSqlDate(split[1],"yyyy-mm-dd hh:mm:ss");
            this.message = split[2];
            this.ID = Integer.parseInt(split[3]);
        } else {
            throw new IllegalArgumentException("The String to parse does not contain enough tabulations and cannot be parsed");
        }
    }

    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        json.put("ID", this.ID);
        json.put("username", this.userName);
        json.put("timestamp", this.time2);
        json.put("messagez`", this.message);
        return json;
    }
}
