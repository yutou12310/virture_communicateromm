package programming3.chatsys.data;

import org.json.JSONObject;

import java.util.Objects;

public class User {
   // public static User u;
    private String userName;
    private String password;
    private String fullName;
    private int lastReadId = 0;

    public int getLastReadId() {
        return lastReadId;
    }

    public void setLastReadId(int lastReadId) {
        this.lastReadId = lastReadId;
    }

    public User(String userName, String password, String fullName) {
        this.userName = userName;
        this.password = password;
        this.fullName = fullName;
    }

    public User(String userName, String password, String fullName, int lastReadId) {
        this.userName = userName;
        this.password = password;
        this.fullName = fullName;
        this.lastReadId = lastReadId;
    }

    public User(JSONObject json) {
        this.userName = json.getString("username");
        this.password = json.getString("password");
        this.fullName = json.getString("fullname");

    }

    public User(String formatted) {this.parse(formatted);}

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String format() {
        return this.userName + "\t" + this.password + "\t" + this.fullName + "\t" + this.lastReadId;
    }

//    @Override
//    public String toString() {
//        return "User{" +
//                "userName='" + userName + '\'' +
//                ", password='" + password + '\'' +
//                ", fullName='" + fullName + '\'' +
//                '}';
//    }


    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", fullName='" + fullName + '\'' +
                ", lastReadId=" + lastReadId +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(userName, user.userName) &&
                Objects.equals(password, user.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userName, password);
    }

    public void parse(String s) {
        String[] split = s.split("\t");
        if (split.length == 4) {
            this.userName = split[0];
            this.password = split[1];
            this.fullName = split[2];
            this.lastReadId = Integer.parseInt(split[3]);
        } else {
            throw new IllegalArgumentException("The String to parse does not contain enough tabulations and cannot be parsed");
        }
    }

    //Json
    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        json.put("username", this.userName);
        json.put("password", this.password);
        json.put("fullname", this.fullName);
        return json;
    }

}



