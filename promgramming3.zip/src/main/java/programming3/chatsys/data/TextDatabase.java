package programming3.chatsys.data;

import java.io.*;

public class TextDatabase extends InMemoryDatabase {
    private File userDB;
    private File ChatMessageDB;

    public TextDatabase(File userDB, File ChatMessageDB) {
        this.userDB = userDB;
        this.ChatMessageDB = ChatMessageDB;
        System.out.println("in text");
        this.loadUsers();
        this.loadMessages();

   }

    /**
     * when close the process, it will save the users and messages
     */
    @Override
    public void close()  {
        this.saveUsers();
        this.saveMessages();
    }

    /**
     * it will save the users to the userDB, firstly, traverse the users, and the parse the users and write them
     */
    private void saveUsers()  {
      System.out.println("Saving users.....");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(this.userDB))) {
              for (User u: this.users){
                writer.write(u.format() + "\r\n");
            }
              writer.close();
       }catch (IOException e) {
           throw new DatabaseAccessException("Cannot write user DB file" + this.userDB, e);
       }

    }

    /**
     * it will read the users form the DBfile you create
     */
   private void loadUsers(){
       System.out.println("Loading users.....");
       if (this.userDB.exists()) {
           try (BufferedReader reader = new BufferedReader(new FileReader(this.userDB))) {
               while (true) {
                   String line = reader.readLine();
                   if (line == null) {
                       break;
                   } else {
                       User u = new User(line);
                       this.users.add(u);
                   }
               }
           } catch (IOException e) {
               throw new DatabaseAccessException("Cannot access user DB file" + this.userDB, e);
           }
       }
   }

    /**
     * the same function as the saveUsers
     */
   public void saveMessages(){
       System.out.println("Saving messages.....");
       try (BufferedWriter writer = new BufferedWriter(new FileWriter(this.ChatMessageDB))){
           for (ChatMessage m: this.chatMessages){
             writer.write(m.format()+"\r\n");
            }
             writer.close();
        }catch (IOException e) {
            throw new DatabaseAccessException("Cannot write user DB file" + this.ChatMessageDB, e);
        }
   }

    /**
     * the same function as loadUsers
     */
    private void loadMessages(){
        System.out.println("Loading messages.....");
        if (this.ChatMessageDB.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(this.ChatMessageDB))) {
                while (true) {
                   String line = reader.readLine();
                   if (line == null) {
                       break;
                    } else {
                      ChatMessage c = new ChatMessage(line);
                      this.chatMessages.add(c);
                    }
                }
            } catch (IOException e) {
                throw new DatabaseAccessException("Cannot access chatMessage DB file" + this.ChatMessageDB, e);
            }
        }
   }
}
