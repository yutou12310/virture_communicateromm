package http;
import Protocol.JSONProtocol;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import programming3.chatsys.data.ChatMessage;
import programming3.chatsys.data.DatabaseAccessException;
import java.io.*;
import java.util.List;

public class RecentMessageHandler extends AbstractHandler {
    private final HTTPChatServer server;

    public RecentMessageHandler(HTTPChatServer server) {
        this.server = server;
    }

    /**
     * @param exchange response code
     */
    @Override
    public void handle(HttpExchange exchange) {
        System.out.println("Got request from client");
        if (exchange.getRequestMethod().equals("GET")) {
            try {
                sendMessages(exchange, parseN(exchange));
            } catch(NumberFormatException e) {
                sendResponse(exchange, 400, "Number of chat messages should be provided in URL");
            }
        } else {
            sendResponse(exchange, 405, "Request method should be GET");
        }
    }

    /**
     * @param exchange response code
     * @param n you num of recent message you want to get
     */
    private void sendMessages(HttpExchange exchange, int n) {
        if (n > 0) {
            List<ChatMessage> messages = this.server.getRecentMessage(n);
            try {
                sendMessages(exchange, messages);
            } catch(DatabaseAccessException e) {
                sendResponse(exchange, 500, "Database cannot be accessed.");
            }
        } else {
            sendResponse(exchange, 400, "Number of chat messages should be > 0");
        }
    }

    /**
     * @param exchange response code
     * @param messages messages added in the list
     */
    protected void sendMessages(HttpExchange exchange, List<ChatMessage> messages) {
        String response = "";
        for (ChatMessage message: messages) {
            response += message.getID() + "\t" + message.getMessage() + "\t";
            response += message.getUser() + "\t" + message.getTime().getTime() + "\r\n";
        }
        this.sendResponse(exchange, 200, response);
    }

    /**
     * @param exchange the response server
     * @return
     */
    private int parseN(HttpExchange exchange) {
        String path = exchange.getRequestURI().getPath();
        String context = exchange.getHttpContext().getPath();
        return Integer.parseInt(path.substring(context.length()));
    }
    public HTTPChatServer getServer(){
        return this.server;
    }


}

