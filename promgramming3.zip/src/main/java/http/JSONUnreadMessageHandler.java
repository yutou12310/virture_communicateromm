package http;

import Protocol.JSONProtocol;
import com.sun.net.httpserver.HttpExchange;
import programming3.chatsys.data.ChatMessage;

import java.io.BufferedWriter;
import java.io.StringWriter;
import java.util.List;

public class JSONUnreadMessageHandler extends UnreadMessageHandler {
    public JSONUnreadMessageHandler(HTTPChatServer server) {
        super(server);
    }
    @Override
    protected void sendMessages(HttpExchange exchange, List<ChatMessage> messages) {
        try {
            StringWriter string = new StringWriter();
            JSONProtocol protocol = new JSONProtocol(new BufferedWriter(string));
            protocol.writeMessage(messages);
            sendResponse(exchange, 200, string.toString());
        } catch (Exception e) {
            sendResponse(exchange, 500, "sever error");
        }
    }
}
