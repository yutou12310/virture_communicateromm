package http;

import Protocol.JSONProtocol;
import com.sun.net.httpserver.HttpExchange;
import programming3.chatsys.data.ChatMessage;
import programming3.chatsys.data.DatabaseAccessException;
import java.io.*;
import java.util.List;

public class JSONRecentMessageHandler extends RecentMessageHandler{
    public JSONRecentMessageHandler(HTTPChatServer server){super(server);}
    @Override
    protected void sendMessages(HttpExchange exchange, List<ChatMessage> messages) {
            try {
                messages = messages;
                StringWriter string = new StringWriter();
                JSONProtocol protocol = new JSONProtocol(new BufferedWriter(string));
                protocol.writeMessage(messages);
                sendResponse(exchange, 200, string.toString());
            } catch (DatabaseAccessException e) {
                sendResponse(exchange, 500, "Database cannot be accessed.");
            } catch (IOException e) {
                sendResponse(exchange, 500, "IOException");
            }
    }
}
