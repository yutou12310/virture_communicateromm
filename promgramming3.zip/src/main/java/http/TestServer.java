package http;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;

public class TestServer {
    public static  void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8887),0);
        server.createContext("/", new HttpHandler() {
            @Override
            public void handle(HttpExchange httpExchange) throws IOException {
                System.out.println("Requested URI: " + httpExchange.getRequestURI());
                System.out.println("Client:" + httpExchange.getRemoteAddress());
                System.out.println("Requested Method:" + httpExchange.getRequestMethod());
                System.out.println("Requested header:" + httpExchange.getRequestHeaders().entrySet());
                BufferedReader reader = new BufferedReader(new InputStreamReader(httpExchange.getRequestBody()));
                System.out.println("Request body:");
                for(String Line = reader.readLine(); Line != null; Line = reader.readLine()){
                    System.out.println(Line);
                }
                String response = "Hello World";
                System.out.println("Sending Response:" + response);
                try{
                httpExchange.sendResponseHeaders(200, response.getBytes("UTF-8").length);
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(httpExchange.getResponseBody()));
                writer.write(response);
                writer.flush();
                writer.close();
                }
                catch (IOException e){
                    System.out.println(e);
                }
                System.out.println("Request sent");
                System.out.println();
            }
        });
        server.start();
        System.out.println("11111111");
    }
}
