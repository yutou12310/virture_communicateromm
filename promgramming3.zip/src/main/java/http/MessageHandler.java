package http;


import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import programming3.chatsys.data.ChatMessage;
import programming3.chatsys.data.DatabaseAccessException;
import programming3.chatsys.data.User;

import java.io.*;

public class MessageHandler extends AbstractHandler {

    private final HTTPChatServer server;

    public MessageHandler(HTTPChatServer server) {
        this.server = server;
    }

    /** handle the exchange
     * @param exchange response code
     */
    @Override
    public void handle(HttpExchange exchange) {
        System.out.println("Got request from client");
        if (exchange.getRequestMethod().equals("POST")) {
            String information = exchange.getRequestURI().toString();
            information = information.substring(10);
            String[] userInformation = splitRequestBody(information);
            if(this.server.authenticate(userInformation[0],userInformation[1])){
                ChatMessage chatMessage = parseMessage(exchange,userInformation[0]);
                if (chatMessage !=null){
                    handleMessage(exchange,chatMessage);
                }
            }else {
                sendResponse(exchange, 400, "The user name or password is incorrect");
            }
        } else {
            sendResponse(exchange, 405, "Request method should be POST");
        }
    }

    /** parse the message and get the correct form of message
     * @param exchange response code
     * @param username the name of users
     * @return the new message
     */
    protected ChatMessage parseMessage(HttpExchange exchange,String username) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(exchange.getRequestBody()))) {
            String message = reader.readLine();
            System.out.println("here");
            System.out.println(message);
            if (message!=null) {
//                System.out.println(new ChatMessage(username,message));
                return new ChatMessage(username,message);
            } else {
                sendResponse(exchange,400,"Information is empty!");
            }
        } catch (IOException e) {
            sendResponse(exchange, 400, "Cannot read from request body.");
        } catch (NullPointerException e) {
            sendResponse(exchange, 400, "No response body provided.");
        }
        return null;
    }

    /**handle the message you get
     * @param exchange response code
     * @param chatMessage the message
     */
    private void handleMessage(HttpExchange exchange, ChatMessage chatMessage) {
        try {
            if (this.server.addMessage(chatMessage.getUser(),chatMessage.getMessage())!=null) {
                System.out.println("add:"+ chatMessage.getUser()+chatMessage.getMessage());
                sendResponse(exchange, 201, "Message was successfully add");
            //    System.out.println(this.server.getRecentMessage(2));
            }
            System.out.println("Message received from client: " +chatMessage);
        } catch (DatabaseAccessException e) {
            sendResponse(exchange, 500, "Database cannot be accessed.");
        }
    }
    /**split the requestbody
     * @param line the requestbody
     * @return an array called userInformation
     */
    public String[] splitRequestBody(String line){
        String[] userInformation = new String[1024];
        String username = line.split("&")[0];
        String password = line.split("&")[1];
        userInformation[0]=username.split("=")[1];
        userInformation[1]=password.split("=")[1];
        return userInformation;
    }
}
