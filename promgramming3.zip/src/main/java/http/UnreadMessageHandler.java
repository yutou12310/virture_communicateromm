package http;

import Protocol.JSONProtocol;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import programming3.chatsys.data.ChatMessage;
import programming3.chatsys.data.DatabaseAccessException;
import programming3.chatsys.data.User;

import java.io.*;
import java.util.List;

public class UnreadMessageHandler extends AbstractHandler {
    private final HTTPChatServer server;

    public UnreadMessageHandler(HTTPChatServer server) {
        this.server = server;
    }

    /**handle the exchange
     * @param exchange response code
     */
    @Override
    public void handle(HttpExchange exchange) {
        System.out.println("Got request from client");
        if (exchange.getRequestMethod().equals("GET")) {
            try {
                String information = exchange.getRequestURI().toString();
                information = information.substring(9);
                String[] userInformation = splitRequestBody(information);
                System.out.println(userInformation[0]);
                System.out.println(userInformation[1]);
                if(this.server.authenticate(userInformation[0],userInformation[1])){
                    sendMessages(exchange,userInformation[0]);
                }else {
                    sendResponse(exchange, 400, "The user name or password is incorrect");
                }
                sendMessages(exchange, information);
            } catch(NumberFormatException e) {
                sendResponse(exchange, 400, "UserName of chat messages should be provided in URL");
            }
        } else {
            sendResponse(exchange, 405, "Request method should be GET");
        }
    }

    /**send the message to database
     * @param exchange
     * @param username the username you want to get
     */
    private void sendMessages(HttpExchange exchange, String username) {
        if (username!=null) {
            List<ChatMessage> messages = this.server.getUnreadMessage(username);
            try {
                sendMessages(exchange, messages);
            } catch(DatabaseAccessException e) {
                sendResponse(exchange, 500, "Database cannot be accessed.");
            }
        } else {
            sendResponse(exchange, 400, "Number of chat messages should be null");
        }
    }

    /**send the messages
     * @param exchange response code
     * @param messages messages added in the list of chatmessage
     */
    protected void sendMessages(HttpExchange exchange, List<ChatMessage> messages) {
        String response = "";
        for (ChatMessage message: messages) {
            response += message.getID() + "\t" + message.getMessage() + "\t";
            response += message.getUser() + "\t" + message.getTime().getTime() + "\r\n";
        }
        this.sendResponse(exchange, 200, response);
    }

    /**split the requestBody
     * @param line the requestBody
     * @return userInformation
     */
    public String[] splitRequestBody(String line){
        String[] userInformation = new String[1024];
        String username = line.split("&")[0];
        String password = line.split("&")[1];
        userInformation[0]=username.split("=")[1];
        userInformation[1]=password.split("=")[1];
        return userInformation;
    }

    public HTTPChatServer getServer(){
        return this.server;
    }

}
