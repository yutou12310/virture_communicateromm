package http;

import programming3.chatsys.data.*;
import java.io.File;
import java.io.IOException;

/**
 * run the httpSever
 * create two path of the textDatabase and SQLiteDatabase, the port of them are 9997 and 9998
 * choose different port and then can use different database
 */
public class RunHTTPServer  {
    private final static File DB_FILE = new File("test.db");
    private static final File USER_DB_FILE = new File("test_user_db.txt");
    private static final File MESSAGE_DB_FILE = new File("test_message_db.txt");
    public static void main(String[] args) {
        try{
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e){
            e.printStackTrace();
        }
        Database db = new SQLiteDatabase("jdbc:sqlite:" + DB_FILE.getPath());
        Database db1 = new TextDatabase(USER_DB_FILE, MESSAGE_DB_FILE);
        HTTPChatServer server = new HTTPChatServer(9998, db,"json");
        HTTPChatServer server1 = new HTTPChatServer(9997, db1);
        try {
            server.start();
            server1.start();
        } catch (IOException e) {
            System.out.println("Server could not be started.");
            e.printStackTrace();
        }
    }

}
