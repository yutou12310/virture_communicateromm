package Protocol;

import org.json.JSONArray;
import org.json.JSONObject;
import programming3.chatsys.data.ChatMessage;
import programming3.chatsys.data.User;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class JSONProtocol {
    private BufferedWriter writer;
    private BufferedReader reader;


    public JSONProtocol(BufferedWriter writer, BufferedReader reader) {
        this.writer = writer;
        this.reader = reader;
    }

    public JSONProtocol(BufferedReader reader) {
        this.reader = reader;
    }

    public JSONProtocol(BufferedWriter writer) {
        this.writer = writer;
    }

    /**
     * @return a user in json form
     * @throws IOException form is not correct
     */
    public User readUser() throws IOException {
        String json = "";
        String line;
        while ((line = this.reader.readLine()) != null) {
            json += line;
        }
        return new User(new JSONObject(json));
    }

    /**
     * @param user json form user
     * @throws IOException form is correct
     */
    public void writeUser(User user) throws IOException {
        JSONObject json = user.toJSON();
        json.write(this.writer);
        this.writer.flush();
    }

    /**
     * @return a list of json form user
     * @throws IOException form is correct
     */
    public List<ChatMessage> readMessage() throws IOException {
        String json = "";
        String line;
        List<ChatMessage> messages = new LinkedList<>();
        while ((line = this.reader.readLine()) != null) {
            json += line;
        }
//        JSONArray jsonArray = new JSONArray(json);
        JSONArray jsonArray = new JSONArray(json);
        System.out.println(jsonArray);
        if (jsonArray.length() > 0) {
            for (int i = 0; i < jsonArray.length(); i++) {
                messages.add(new ChatMessage(jsonArray.getJSONObject(i)));
            }
        }
        return messages;
    }

    /**
     * @param messages add in the database
     * @throws IOException form is correct
     */
    public void writeMessage(List<ChatMessage> messages) throws IOException {
//        JSONArray jsonArray = new JSONArray(messages);
//        for(int w = 0; w<messages.size();w++){
//            JSONObject jsonObject = messages.get(w).toJSON();
//            jsonObject.write(this.writer);
//        }
//
//        writer.flush();
//    }
        JSONArray objects = new JSONArray();
        for (ChatMessage chatMessage : messages) {
            objects.put(chatMessage.toJSON());
        }
        JSONObject jsonObject = new JSONObject();
        System.out.println(jsonObject.put("messages", objects));
        jsonObject.write(this.writer);
        this.writer.flush();
    }
}
